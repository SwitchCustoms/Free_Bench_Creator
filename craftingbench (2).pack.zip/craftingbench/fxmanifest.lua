fx_version 'cerulean'
game 'gta5'

name 'craftingbench'
author 'Cody'
description 'Custom NUI crafting bench'
version '1.0.0'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js'
}

-- FORCE LOAD ORDER
shared_script '@ox_lib/init.lua'
shared_script 'shared/config.lua'

shared_scripts {
    'shared/items.lua'
}

client_scripts {
    'client/main.lua',
    'client/menu.lua',
    'client/placement.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'config.lua',
    'server/main.lua',
    'server/sql.lua'
}

dependency 'ox_lib'

lua54 'yes'

dependency '/assetpacks'