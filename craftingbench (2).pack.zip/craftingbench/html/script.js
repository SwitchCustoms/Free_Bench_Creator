let currentItems = [];
let currentBenchName = 'Workbench';
let selectedRecipe = null;

const root = document.getElementById('crafting-root');
const itemGrid = document.getElementById('cb-item-grid');
const benchNameEl = document.getElementById('cb-bench-name');

const bpPanel = document.getElementById('cb-blueprint-panel');
const bpPlaceholder = document.getElementById('cb-blueprint-placeholder');
const bpTitle = document.getElementById('bp-title');
const bpAmount = document.getElementById('bp-amount');
const bpImage = document.getElementById('bp-image');
const bpCraftBtn = document.getElementById('bp-craft-btn');
const bpIngredients = document.getElementById('bp-ingredients');

const closeBtn = document.getElementById('cb-close-btn');

// OPEN UI
function openUI(data) {
    currentItems = data.items || [];
    currentBenchName = data.benchName || 'Workbench';

    benchNameEl.textContent = currentBenchName.toUpperCase();
    renderItems();

    root.classList.remove('hidden');
}

// CLOSE UI (manual close only)
function closeUI() {
    root.classList.add('hidden');
    selectedRecipe = null;

    // Reset right panel
    bpPanel.classList.add('hidden');
    bpPlaceholder.classList.remove('hidden');
    bpIngredients.innerHTML = '';

    // Only manual close should notify Lua
    fetch(`https://${GetParentResourceName()}/close`, {
        method: 'POST',
        body: JSON.stringify({})
    });
}

// RENDER ITEMS
function renderItems() {
    itemGrid.innerHTML = '';

    if (!currentItems || currentItems.length === 0) {
        const empty = document.createElement('div');
        empty.className = 'cb-item-card';
        empty.innerHTML = `
            <div class="cb-item-info">
                <div class="cb-item-label">No recipes available</div>
                <div class="cb-item-amount">Configure recipes in database.</div>
            </div>`;
        itemGrid.appendChild(empty);
        return;
    }

    currentItems.forEach((item) => {
        const card = document.createElement('div');
        card.className = 'cb-item-card';

        const iconWrapper = document.createElement('div');
        iconWrapper.className = 'cb-item-icon-wrapper';

        if (item.image) {
            const img = document.createElement('img');
            img.src = item.image;
            img.className = 'cb-item-icon';
            iconWrapper.appendChild(img);
        } else {
            const fallback = document.createElement('div');
            fallback.className = 'cb-item-fallback';
            fallback.textContent = 'NO IMAGE';
            iconWrapper.appendChild(fallback);
        }

        const info = document.createElement('div');
        info.className = 'cb-item-info';

        const label = document.createElement('div');
        label.className = 'cb-item-label';
        label.textContent = item.label || 'Unknown';

        const amount = document.createElement('div');
        amount.className = 'cb-item-amount';
        amount.textContent = 'x' + (item.amount || 1);

        info.appendChild(label);
        info.appendChild(amount);

        card.appendChild(iconWrapper);
        card.appendChild(info);

        // CLICK → SHOW BLUEPRINT PANEL
        card.addEventListener('click', () => showBlueprint(item));

        itemGrid.appendChild(card);
    });
}

// SHOW BLUEPRINT PANEL (RIGHT SIDE)
function showBlueprint(item) {
    selectedRecipe = item;

    bpTitle.textContent = item.label || 'Unknown';
    bpAmount.textContent = 'x' + (item.amount || 1);
    bpImage.src = item.image || '';

    // ⭐ FIXED REQUIREMENTS LIST ⭐
    bpIngredients.innerHTML = '';

    if (item.requirements && item.requirements.length > 0) {
        item.requirements.forEach(req => {
            const row = document.createElement('div');
            row.className = 'bp-ingredient-row';
            row.textContent = `${req.item.toUpperCase()} x${req.amount}`;
            bpIngredients.appendChild(row);
        });
    } else {
        const row = document.createElement('div');
        row.className = 'bp-ingredient-row';
        row.textContent = 'No requirements';
        bpIngredients.appendChild(row);
    }

    bpPlaceholder.classList.add('hidden');
    bpPanel.classList.remove('hidden');
}

// CRAFT BUTTON
bpCraftBtn.addEventListener('click', () => {
    if (!selectedRecipe) return;

    fetch(`https://${GetParentResourceName()}/selectRecipe`, {
        method: 'POST',
        body: JSON.stringify({
            benchId: selectedRecipe.benchId,
            recipeId: selectedRecipe.recipeId
        })
    });

    root.classList.add('hidden');
    selectedRecipe = null;

    bpPanel.classList.add('hidden');
    bpPlaceholder.classList.remove('hidden');
    bpIngredients.innerHTML = '';
});

// CLOSE BUTTON
closeBtn.addEventListener('click', closeUI);

// ESC closes UI
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeUI();
});

// NUI MESSAGE LISTENER
window.addEventListener('message', (event) => {
    const data = event.data;
    if (!data || !data.action) return;

    if (data.action === 'open') {
        openUI(data);
    }
    else if (data.action === 'close') {
        root.classList.add('hidden');
    }
});
